package com.example.praktikum3.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.praktikum3.R;
import com.example.praktikum3.jclass.Story;

import java.util.ArrayList;

public class StoryHighlightAdapter extends RecyclerView.Adapter<StoryHighlightAdapter.ViewHolder> {

    private ArrayList<Story> storyList;
    private OnStoryClickListener storyClickListener;

    public interface OnStoryClickListener {
        void onStoryClick(Story story);
    }

    public StoryHighlightAdapter(ArrayList<Story> storyList, OnStoryClickListener listener) {
        this.storyList = storyList;
        this.storyClickListener = listener;
    }

    @NonNull
    @Override
    public StoryHighlightAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_highlight, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryHighlightAdapter.ViewHolder holder, int position) {
        Story story = storyList.get(position);

        Glide.with(holder.itemView.getContext())
                .load(story.getImageRes())
                .override(120, 120)
                .circleCrop()
                .into(holder.imageView);

        holder.textView.setText(story.getTitle());

        holder.itemView.setOnClickListener(v -> storyClickListener.onStoryClick(story));
    }

    @Override
    public int getItemCount() {
        return storyList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.iv_story);
            textView = itemView.findViewById(R.id.tv_story_name);
        }
    }
}
