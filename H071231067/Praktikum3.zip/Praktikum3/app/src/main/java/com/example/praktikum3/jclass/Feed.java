package com.example.praktikum3.jclass;

import android.net.Uri;

public class Feed {
    private int imageRes = -1;
    private String imageUriString;
    private String caption;

    // Drawable resource
    public Feed(int imageRes, String caption) {
        this.imageRes = imageRes;
        this.caption = caption;
    }

    // Uri
    public Feed(Uri imageUri, String caption) {
        this.imageRes = -1;
        this.imageUriString = imageUri.toString();
        this.caption = caption;
    }

    public boolean isFromResource() {
        return imageRes != -1;
    }

    public boolean isFromUri() {
        return imageUriString != null;
    }

    public int getImageRes() {
        return imageRes;
    }

    public Uri getImageUri() {
        return Uri.parse(imageUriString);
    }

    public String getCaption() {
        return caption;
    }
}

