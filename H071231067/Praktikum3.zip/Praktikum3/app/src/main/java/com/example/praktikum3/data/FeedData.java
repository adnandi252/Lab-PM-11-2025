package com.example.praktikum3.data;

import com.example.praktikum3.R;
import com.example.praktikum3.jclass.Feed;

import java.util.ArrayList;

public class FeedData {
    private static ArrayList<Feed> feedList = new ArrayList<>();
    static {
        feedList.add(new Feed(R.drawable.feed1, "Rawa"));
        feedList.add(new Feed(R.drawable.feed2, "Rawa2"));
        feedList.add(new Feed(R.drawable.feed3, "Padang Rumput"));
        feedList.add(new Feed(R.drawable.feed4, "Evening"));
        feedList.add(new Feed(R.drawable.feed5, "Tower"));
        feedList.add(new Feed(R.drawable.feed6, "Good Photo Spot"));
        feedList.add(new Feed(R.drawable.feed7, "Sepeda"));
        feedList.add(new Feed(R.drawable.feed8, "Sky"));
        feedList.add(new Feed(R.drawable.feed9, "Tree"));
        feedList.add(new Feed(R.drawable.feed10, "Mountain"));
    }

    public static ArrayList<Feed> getFeedList() {
        return feedList;
    }

    public static void addFeed(Feed newFeed) {
        feedList.add(0, newFeed);
    }
}
