package com.example.praktikum3.data;

import com.example.praktikum3.R;
import com.example.praktikum3.jclass.Story;

import java.util.ArrayList;

public class StoryData {
    public static ArrayList<Story> getStoryList() {
        ArrayList<Story> stories = new ArrayList<>();

        stories.add(new Story(R.drawable.story1, "Kota"));
        stories.add(new Story(R.drawable.story2, "Pohon"));
        stories.add(new Story(R.drawable.story3, "Foto Batu"));
        stories.add(new Story(R.drawable.story4, "Awan"));
        stories.add(new Story(R.drawable.story5, "Bunga"));
        stories.add(new Story(R.drawable.story6, "Sunset"));

        return stories;
    }
}

