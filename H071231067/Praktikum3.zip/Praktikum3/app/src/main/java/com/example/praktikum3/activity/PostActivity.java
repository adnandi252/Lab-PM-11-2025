package com.example.praktikum3.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;

import androidx.annotation.Nullable;

import com.example.praktikum3.jclass.Feed;
import com.example.praktikum3.data.FeedData;
import com.example.praktikum3.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class PostActivity extends Activity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView imagePreview;
    private EditText captionInput;
    private Button btnChooseImage, btnUpload;

    private Uri selectedImageUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        imagePreview = findViewById(R.id.image_preview);
        captionInput = findViewById(R.id.et_caption);
        btnChooseImage = findViewById(R.id.btn_choose_image);
        btnUpload = findViewById(R.id.btn_upload);

        btnChooseImage.setOnClickListener(v -> openGallery());

        btnUpload.setOnClickListener(v -> {
            String caption = captionInput.getText().toString();
            if (selectedImageUri != null && !caption.isEmpty()) {
                Feed newFeed = new Feed(selectedImageUri, caption);
                FeedData.addFeed(newFeed);
                Toast.makeText(PostActivity.this, "Feed berhasil di-upload!", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(PostActivity.this, ProfileActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(PostActivity.this, "Lengkapi gambar dan caption!", Toast.LENGTH_SHORT).show();
            }
        });

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_post);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(PostActivity.this, MainActivity.class));
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(PostActivity.this, ProfileActivity.class));
                return true;
            }
            return false;
        });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            imagePreview.setImageURI(selectedImageUri);
        }
    }
}
