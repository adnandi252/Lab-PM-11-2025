package com.example.praktikum3.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.praktikum3.R;
import com.example.praktikum3.activity.OtherProfileActivity;
import com.example.praktikum3.jclass.Home;

import java.util.ArrayList;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.HomeViewHolder> {
    private ArrayList<Home> homeList;
    private Context context;

    public HomeAdapter(Context context, ArrayList<Home> homeList) {
        this.context = context;
        this.homeList = homeList;
    }

    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_feed, parent, false);
        return new HomeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder holder, int position) {
        Home home = homeList.get(position);

        Glide.with(context)
                .load(home.getProfileImage())
                .into(holder.profileImage);

        Glide.with(context)
                .load(home.getPostImage())
                .into(holder.postImage);

        holder.caption.setText(home.getCaption());
        holder.username.setText(home.getUsername());

        View.OnClickListener profileClickListener = v -> {
            Intent intent = new Intent(context, OtherProfileActivity.class);
            intent.putExtra("username", home.getUsername());
            intent.putExtra("profileImage", home.getProfileImage());
            intent.putIntegerArrayListExtra("postList", home.getPostList());
            context.startActivity(intent);
        };

        holder.profileImage.setOnClickListener(profileClickListener);
        holder.username.setOnClickListener(profileClickListener);
    }

    @Override
    public int getItemCount() {
        return homeList.size();
    }

    public static class HomeViewHolder extends RecyclerView.ViewHolder {
        ImageView profileImage, postImage;
        TextView caption, username;

        public HomeViewHolder(@NonNull View itemView) {
            super(itemView);
            profileImage = itemView.findViewById(R.id.iv_profile);
            postImage = itemView.findViewById(R.id.iv_post);
            caption = itemView.findViewById(R.id.tv_caption);
            username = itemView.findViewById(R.id.tv_username);
        }
    }
}