package com.example.praktikum3.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.praktikum3.R;
import com.example.praktikum3.adapter.OtherUserFeedAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class OtherProfileActivity extends AppCompatActivity {

    private CircleImageView ivOtherProfile;
    private TextView tvOtherUsername, tvOtherBio;
    private RecyclerView rvOtherProfileFeed;
    private ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_profile);

        ivOtherProfile = findViewById(R.id.iv_other_profile);
        tvOtherUsername = findViewById(R.id.tv_other_username);
        tvOtherBio = findViewById(R.id.tv_other_bio);
        rvOtherProfileFeed = findViewById(R.id.rv_other_profile_feed);
        btnBack = findViewById(R.id.btn_back);

        String username = getIntent().getStringExtra("username");
        int profileImage = getIntent().getIntExtra("profileImage", -1);
        ArrayList<Integer> postList = getIntent().getIntegerArrayListExtra("postList");

        ivOtherProfile.setImageResource(profileImage);
        tvOtherUsername.setText(username);
        tvOtherBio.setText("Ini bio dari " + username);

        rvOtherProfileFeed.setLayoutManager(new GridLayoutManager(this, 3));
        OtherUserFeedAdapter adapter = new OtherUserFeedAdapter(this, postList, username, profileImage);
        rvOtherProfileFeed.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_profile);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_post) {
                startActivity(new Intent(OtherProfileActivity.this, PostActivity.class));
                return true;
            } else if (id == R.id.nav_home) {
                startActivity(new Intent(OtherProfileActivity.this, MainActivity.class));
                return true;
            }
            else if (id == R.id.nav_profile) {
                startActivity(new Intent(OtherProfileActivity.this, ProfileActivity.class));
                return true;
            }
            return false;
        });
    }
}