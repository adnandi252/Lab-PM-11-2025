package com.example.praktikum3.data;

import com.example.praktikum3.R;
import com.example.praktikum3.jclass.Home;

import java.util.ArrayList;

public class HomeData {
    public static ArrayList<Home> getHomeList() {
        ArrayList<Home> homeList = new ArrayList<>();

        ArrayList<Integer> ganyuPosts = new ArrayList<>();
        ganyuPosts.add(R.drawable.post1);
        ganyuPosts.add(R.drawable.ganyupost1);
        ganyuPosts.add(R.drawable.ganyupost2);

        ArrayList<Integer> nilouPosts = new ArrayList<>();
        nilouPosts.add(R.drawable.post2);
        nilouPosts.add(R.drawable.niloupost1);
        nilouPosts.add(R.drawable.niloupost2);

        ArrayList<Integer> razorPosts = new ArrayList<>();
        razorPosts.add(R.drawable.post3);

        ArrayList<Integer> profile4Posts = new ArrayList<>();
        profile4Posts.add(R.drawable.post4);

        ArrayList<Integer> profile5Posts = new ArrayList<>();
        profile5Posts.add(R.drawable.post5);

        ArrayList<Integer> profile6Posts = new ArrayList<>();
        profile6Posts.add(R.drawable.post6);

        ArrayList<Integer> profile7Posts = new ArrayList<>();
        profile7Posts.add(R.drawable.post7);

        ArrayList<Integer> profile8Posts = new ArrayList<>();
        profile8Posts.add(R.drawable.post8);

        ArrayList<Integer> profile9Posts = new ArrayList<>();
        profile9Posts.add(R.drawable.post9);

        ArrayList<Integer> profile10Posts = new ArrayList<>();
        profile10Posts.add(R.drawable.post10);

        homeList.add(new Home(R.drawable.profile1, R.drawable.post1, "Ganyu", "Ganyu", ganyuPosts));
        homeList.add(new Home(R.drawable.profile2, R.drawable.post2, "Nilou", "Nilou", nilouPosts));
        homeList.add(new Home(R.drawable.profile3, R.drawable.post3, "Razor", "Razor", razorPosts));
        homeList.add(new Home(R.drawable.profile4, R.drawable.post4, "Yunjin", "Yunjin", profile4Posts));
        homeList.add(new Home(R.drawable.profile5, R.drawable.post5, "Yoimiya", "Yoimiya", profile5Posts));
        homeList.add(new Home(R.drawable.profile6, R.drawable.post6, "Yelan", "Yelan", profile6Posts));
        homeList.add(new Home(R.drawable.profile7, R.drawable.post7, "Zhongli", "Zhongli", profile7Posts));
        homeList.add(new Home(R.drawable.profile8, R.drawable.post8, "YaoYao", "YaoYao", profile8Posts));
        homeList.add(new Home(R.drawable.profile9, R.drawable.post9, "Yae Miko", "Yae Miko", profile9Posts));
        homeList.add(new Home(R.drawable.profile10, R.drawable.post10, "Xinyan", "Xinyan", profile10Posts));

        return homeList;
    }
}