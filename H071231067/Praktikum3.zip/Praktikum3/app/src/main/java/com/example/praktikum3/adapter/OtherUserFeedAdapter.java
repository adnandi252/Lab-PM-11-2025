package com.example.praktikum3.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.praktikum3.R;
import com.example.praktikum3.activity.PostDetailActivity;

import java.util.ArrayList;

public class OtherUserFeedAdapter extends RecyclerView.Adapter<OtherUserFeedAdapter.ViewHolder> {

    private ArrayList<Integer> postList;
    private Context context;
    private String username;
    private int userProfileImageRes;

    public OtherUserFeedAdapter(Context context, ArrayList<Integer> postList, String username, int userProfileImageRes) {
        this.context = context;
        this.postList = postList != null ? postList : new ArrayList<>();
        this.username = username;
        this.userProfileImageRes = userProfileImageRes;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_grid_post, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        int imageRes = postList.get(position);
        Glide.with(context)
                .load(imageRes)
                .into(holder.imageView);

        holder.imageView.setOnClickListener(v -> {
            Intent intent = new Intent(context, PostDetailActivity.class);
            intent.putExtra("feed_image", imageRes);
            intent.putExtra("username", username);
            intent.putExtra("user_profile_image", userProfileImageRes);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.iv_grid_image);
        }
    }
}