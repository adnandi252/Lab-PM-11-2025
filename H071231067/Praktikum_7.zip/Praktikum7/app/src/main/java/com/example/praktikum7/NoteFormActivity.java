package com.example.praktikum7;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.praktikum7.db.DatabaseContract;
import com.example.praktikum7.db.DatabaseHelper;
import com.example.praktikum7.model.Note;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NoteFormActivity extends AppCompatActivity {

    public static final String EXTRA_NOTE = "extra_note";
    public static final String EXTRA_POSITION = "extra_position";
    public static final int REQUEST_ADD = 100;
    public static final int REQUEST_UPDATE = 200;
    public static final int RESULT_ADD = 101;
    public static final int RESULT_UPDATE = 201;
    public static final int RESULT_DELETE = 301;

    TextInputEditText edtTitle, edtDescription;
    Button btnSubmit, btnDelete;
    ImageButton btnBack;
    TextView tvToolbarTitle;
    Note note;
    int position;
    boolean isEdit = false;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_form);

        edtTitle = findViewById(R.id.edt_title);
        edtDescription = findViewById(R.id.edt_description);
        btnSubmit = findViewById(R.id.btn_submit);
        btnDelete = findViewById(R.id.btn_delete);
        btnBack = findViewById(R.id.btn_back);
        tvToolbarTitle = findViewById(R.id.tv_toolbar_title);

        dbHelper = new DatabaseHelper(this);

        note = getIntent().getParcelableExtra(EXTRA_NOTE);
        if (note != null) {
            position = getIntent().getIntExtra(EXTRA_POSITION, 0);
            isEdit = true;
        } else {
            note = new Note();
        }

        if (isEdit) {
            tvToolbarTitle.setText("Edit Note");
            edtTitle.setText(note.getTitle());
            edtDescription.setText(note.getDescription());
            btnDelete.setVisibility(View.VISIBLE);
        } else {
            tvToolbarTitle.setText("Add Note");
            btnDelete.setVisibility(View.GONE);
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBackConfirmDialog();
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = edtTitle.getText().toString().trim();
                String description = edtDescription.getText().toString().trim();

                if (title.isEmpty()) {
                    edtTitle.setError("Field can not be blank");
                    return;
                }
                if (description.isEmpty()) {
                    edtDescription.setError("Field can not be blank");
                    return;
                }

                if (isEdit) {
                    showUpdateConfirmDialog(title, description);
                } else {
                    saveNote(title, description);
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDeleteConfirmDialog();
            }
        });
    }

    private void showBackConfirmDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Exit Form");
        alertDialogBuilder
                .setMessage("Are you sure? Any unsaved changes will be lost.")
                .setCancelable(false)
                .setPositiveButton("Yes", (dialog, id) -> super.onBackPressed())
                .setNegativeButton("No", (dialog, id) -> dialog.cancel());
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void saveNote(String title, String description) {
        note.setTitle(title);
        note.setDescription(description);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String currentDate = sdf.format(new Date());

        String formattedDate;
        if (isEdit) {
            formattedDate = "Updated at " + currentDate;
        } else {
            formattedDate = "Created at " + currentDate;
        }
        note.setDate(formattedDate);

        Intent intent = new Intent();
        intent.putExtra(EXTRA_NOTE, note);
        intent.putExtra(EXTRA_POSITION, position);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.NoteColumns.COLUMN_TITLE, title);
        values.put(DatabaseContract.NoteColumns.COLUMN_DESCRIPTION, description);
        values.put(DatabaseContract.NoteColumns.COLUMN_DATE, formattedDate);

        if (isEdit) {
            db.update(
                    DatabaseContract.NoteColumns.TABLE_NAME,
                    values,
                    DatabaseContract.NoteColumns._ID + " = ?",
                    new String[]{String.valueOf(note.getId())}
            );
            setResult(RESULT_UPDATE, intent);
            Toast.makeText(this, "Note updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            long result = db.insert(DatabaseContract.NoteColumns.TABLE_NAME, null, values);
            if (result > 0) {
                note.setId((int) result);
                setResult(RESULT_ADD, intent);
                Toast.makeText(this, "Note added successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to add note", Toast.LENGTH_SHORT).show();
            }
        }
        finish();
    }

    private void showUpdateConfirmDialog(final String title, final String description) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Confirm Update");
        alertDialogBuilder
                .setMessage("Are you sure you want to update this note?")
                .setCancelable(false)
                .setPositiveButton("Yes", (dialog, id) -> saveNote(title, description))
                .setNegativeButton("No", (dialog, id) -> dialog.cancel());
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void showDeleteConfirmDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Confirm Delete");
        alertDialogBuilder
                .setMessage("Are you sure you want to delete this note?")
                .setCancelable(false)
                .setPositiveButton("Yes", (dialog, id) -> deleteNote())
                .setNegativeButton("No", (dialog, id) -> dialog.cancel());
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void deleteNote() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(
                DatabaseContract.NoteColumns.TABLE_NAME,
                DatabaseContract.NoteColumns._ID + " = ?",
                new String[]{String.valueOf(note.getId())}
        );

        Intent intent = new Intent();
        intent.putExtra(EXTRA_POSITION, position);
        setResult(RESULT_DELETE, intent);
        finish();
    }
}
