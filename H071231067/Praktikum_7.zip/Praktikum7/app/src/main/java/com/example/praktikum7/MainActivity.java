package com.example.praktikum7;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.praktikum7.db.DatabaseContract;
import com.example.praktikum7.db.DatabaseHelper;
import com.example.praktikum7.db.MappingHelper;
import com.example.praktikum7.model.Note;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    NoteAdapter adapter;
    FloatingActionButton fabAdd;
    DatabaseHelper dbHelper;
    RecyclerView rvNotes;
    SearchView searchView;
    TextView tvNoData;
    ArrayList<Note> notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvNotes = findViewById(R.id.rv_notes);
        fabAdd = findViewById(R.id.fab_add);
        searchView = findViewById(R.id.search_view);
        tvNoData = findViewById(R.id.tv_no_data);

        dbHelper = new DatabaseHelper(this);
        notes = new ArrayList<>();

        adapter = new NoteAdapter(this);
        rvNotes.setAdapter(adapter);
        rvNotes.setLayoutManager(new LinearLayoutManager(this));

        loadNotes();

        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, NoteFormActivity.class);
                startActivityForResult(intent, NoteFormActivity.REQUEST_ADD);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchNotes(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchNotes(newText);
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }

    private void loadNotes() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                DatabaseContract.NoteColumns._ID,
                DatabaseContract.NoteColumns.COLUMN_TITLE,
                DatabaseContract.NoteColumns.COLUMN_DESCRIPTION,
                DatabaseContract.NoteColumns.COLUMN_DATE
        };

        Cursor cursor = db.query(
                DatabaseContract.NoteColumns.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                DatabaseContract.NoteColumns._ID + " ASC"
        );

        ArrayList<Note> noteList = MappingHelper.mapCursorToArrayList(cursor);
        cursor.close();

        if (noteList.size() > 0) {
            adapter.setListNotes(noteList);
            tvNoData.setVisibility(View.GONE);
            rvNotes.setVisibility(View.VISIBLE);
        } else {
            adapter.setListNotes(new ArrayList<>());
            tvNoData.setVisibility(View.VISIBLE);
            rvNotes.setVisibility(View.GONE);
        }
    }

    private void searchNotes(String query) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                DatabaseContract.NoteColumns._ID,
                DatabaseContract.NoteColumns.COLUMN_TITLE,
                DatabaseContract.NoteColumns.COLUMN_DESCRIPTION,
                DatabaseContract.NoteColumns.COLUMN_DATE
        };

        String selection = DatabaseContract.NoteColumns.COLUMN_TITLE + " LIKE ?";
        String[] selectionArgs = {"%" + query + "%"};

        Cursor cursor = db.query(
                DatabaseContract.NoteColumns.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                DatabaseContract.NoteColumns._ID + "ASC"
        );

        ArrayList<Note> noteList = MappingHelper.mapCursorToArrayList(cursor);
        cursor.close();

        if (noteList.size() > 0) {
            adapter.setListNotes(noteList);
            tvNoData.setVisibility(View.GONE);
            rvNotes.setVisibility(View.VISIBLE);
        } else {
            adapter.setListNotes(new ArrayList<>());
            tvNoData.setVisibility(View.VISIBLE);
            rvNotes.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data != null) {
            if (requestCode == NoteFormActivity.REQUEST_ADD) {
                if (resultCode == NoteFormActivity.RESULT_ADD) {
                    Note note = data.getParcelableExtra(NoteFormActivity.EXTRA_NOTE);
                    adapter.addItem(note);
                    rvNotes.smoothScrollToPosition(adapter.getItemCount() - 1);
                    Toast.makeText(this, "Note added", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == NoteFormActivity.REQUEST_UPDATE) {
                if (resultCode == NoteFormActivity.RESULT_UPDATE) {
                    Note note = data.getParcelableExtra(NoteFormActivity.EXTRA_NOTE);
                    int position = data.getIntExtra(NoteFormActivity.EXTRA_POSITION, 0);
                    adapter.updateItem(position, note);
                    rvNotes.smoothScrollToPosition(position);
                    Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show();
                } else if (resultCode == NoteFormActivity.RESULT_DELETE) {
                    int position = data.getIntExtra(NoteFormActivity.EXTRA_POSITION, 0);
                    adapter.removeItem(position);
                    Toast.makeText(this, "Note deleted", Toast.LENGTH_SHORT).show();
                }
            }
        }

        searchView.setQuery("", false);
    }
}

