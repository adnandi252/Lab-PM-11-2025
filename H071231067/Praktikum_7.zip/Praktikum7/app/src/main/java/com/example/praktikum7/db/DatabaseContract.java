package com.example.praktikum7.db;

import android.provider.BaseColumns;

public class DatabaseContract {
    public static class NoteColumns implements BaseColumns {
        public static final String TABLE_NAME = "notes";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_DESCRIPTION = "description";
        public static final String COLUMN_DATE = "date";
    }
}
