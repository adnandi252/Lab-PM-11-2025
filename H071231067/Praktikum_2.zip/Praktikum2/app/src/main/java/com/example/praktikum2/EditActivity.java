package com.example.praktikum2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class EditActivity extends AppCompatActivity {

    EditText etName, etHandle, etBio, etInfo1, etInfo2;
    ImageView imgHeader, imgProfile;
    Uri uriHeader = null;
    Uri uriProfile = null;

    ActivityResultLauncher<Intent> launcherHeader;
    ActivityResultLauncher<Intent> launcherProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        etName = findViewById(R.id.etName);
        etHandle = findViewById(R.id.etHandle);
        etBio = findViewById(R.id.etBio);
        etInfo1 = findViewById(R.id.etInfo1);
        etInfo2 = findViewById(R.id.etInfo2);
        imgHeader = findViewById(R.id.imgHeader);
        imgProfile = findViewById(R.id.imgProfile);
        Button btnSave = findViewById(R.id.btnSave);
        ImageButton btnBack = findViewById(R.id.btnBack);

        Intent intent = getIntent();
        etName.setText(intent.getStringExtra("name"));
        etHandle.setText(intent.getStringExtra("handle"));
        etBio.setText(intent.getStringExtra("bio"));
        etInfo1.setText(intent.getStringExtra("info1"));
        etInfo2.setText(intent.getStringExtra("info2"));

        String headerUriStr = intent.getStringExtra("header");
        String profileUriStr = intent.getStringExtra("profile");

        if (headerUriStr != null) {
            uriHeader = Uri.parse(headerUriStr);
            imgHeader.setImageURI(uriHeader);
        }

        if (profileUriStr != null) {
            uriProfile = Uri.parse(profileUriStr);
            imgProfile.setImageURI(uriProfile);
        }

        launcherHeader = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        uriHeader = result.getData().getData();
                        imgHeader.setImageURI(uriHeader);
                    }
                }
        );

        launcherProfile = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        uriProfile = result.getData().getData();
                        imgProfile.setImageURI(uriProfile);
                    }
                }
        );

        imgHeader.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
            pick.setType("image/*");
            launcherHeader.launch(Intent.createChooser(pick, "Pilih Gambar Header"));
        });

        imgProfile.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
            pick.setType("image/*");
            launcherProfile.launch(Intent.createChooser(pick, "Pilih Gambar Profile"));
        });

        // Tombol Save
        btnSave.setOnClickListener(v -> {
            Intent result = new Intent();
            result.putExtra("name", etName.getText().toString());
            result.putExtra("handle",etHandle.getText().toString());
            result.putExtra("bio", etBio.getText().toString());
            result.putExtra("info1", etInfo1.getText().toString());
            result.putExtra("info2", etInfo2.getText().toString());

            if (uriHeader != null) result.putExtra("header", uriHeader.toString());
            if (uriProfile != null) {
                result.putExtra("profile", uriProfile.toString());
                result.putExtra("imgProfilePost", uriProfile.toString());
            }

            setResult(RESULT_OK, result);
            finish();
        });

        // Tombol kembali
        btnBack.setOnClickListener(v -> {
            finish();
        });
    }
}
