package com.example.praktikum2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageView imgHeader, imgProfile, imgProfile2, imgProfile3, imgProfile4;
    TextView tvName, tvHandle, tvBio, tvAdditionalInfo, tvAdditionalInfo2, tvUserName,
             tvUserName2, tvUserName3, tvUserNamePost, tvUserNamePost2, tvUserNamePost3;
    Button btnEdit;

    Uri uriHeader = null;
    Uri uriProfile = null;


    ActivityResultLauncher<Intent> launcherEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgHeader = findViewById(R.id.imgHeader);

        imgProfile = findViewById(R.id.imgProfile);
        imgProfile2 = findViewById(R.id.imgProfilePost);
        imgProfile3 = findViewById(R.id.imgProfilePost2);
        imgProfile4 = findViewById(R.id.imgProfilePost3);

        tvName = findViewById(R.id.tvName);
        tvUserName = findViewById(R.id.tvUserName);
        tvUserName2 = findViewById(R.id.tvUserName2);
        tvUserName3 = findViewById(R.id.tvUserName3);

        tvUserNamePost = findViewById(R.id.tvUserNamePost);
        tvUserNamePost2 = findViewById(R.id.tvUserNamePost2);
        tvUserNamePost3 = findViewById(R.id.tvUserNamePost3);

        tvHandle = findViewById(R.id.tvHandle);
        tvBio = findViewById(R.id.tvBio);
        tvAdditionalInfo = findViewById(R.id.tvAdditionalInfo);
        tvAdditionalInfo2 = findViewById(R.id.tvAdditionalInfo2);
        btnEdit = findViewById(R.id.btnEdit);

        launcherEdit = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();

                        tvName.setText(data.getStringExtra("name"));
                        tvUserName.setText(data.getStringExtra("name"));
                        tvUserName2.setText(data.getStringExtra("name"));
                        tvUserName3.setText(data.getStringExtra("name"));

                        tvHandle.setText(data.getStringExtra("handle"));
                        tvUserNamePost.setText(data.getStringExtra("handle"));
                        tvUserNamePost2.setText(data.getStringExtra("handle"));
                        tvUserNamePost3.setText(data.getStringExtra("handle"));

                        tvBio.setText(data.getStringExtra("bio"));
                        tvAdditionalInfo.setText(data.getStringExtra("info1"));
                        tvAdditionalInfo2.setText(data.getStringExtra("info2"));

                        String headerUriStr = data.getStringExtra("header");
                        String profileUriStr = data.getStringExtra("profile");

                        if (headerUriStr != null) {
                            uriHeader = Uri.parse(headerUriStr);
                            imgHeader.setImageURI(uriHeader);
                        }

                        if (profileUriStr != null) {
                            uriProfile = Uri.parse(profileUriStr);
                            imgProfile.setImageURI(uriProfile);
                            imgProfile2.setImageURI(uriProfile);
                            imgProfile3.setImageURI(uriProfile);
                            imgProfile4.setImageURI(uriProfile);
                        }
                    }
                }
        );

        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditActivity.class);
            intent.putExtra("name", tvName.getText().toString());
            intent.putExtra("handle", tvHandle.getText().toString());
            intent.putExtra("bio", tvBio.getText().toString());
            intent.putExtra("info1", tvAdditionalInfo.getText().toString());
            intent.putExtra("info2", tvAdditionalInfo2.getText().toString());

            launcherEdit.launch(intent);
        });

    }
}
