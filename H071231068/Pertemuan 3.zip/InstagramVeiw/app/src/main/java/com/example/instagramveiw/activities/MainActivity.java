package com.example.instagramveiw.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.instagramveiw.R;
import com.example.instagramveiw.adapters.PostAdapter;
import com.example.instagramveiw.models.Post;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvPosts;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvPosts = findViewById(R.id.rv_posts);
        setupPosts();

        BottomNavigationView bottomNavigation = findViewById(R.id.bottom_navigation);

        bottomNavigation.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.action_home) {
                    return true;
                } else if (itemId == R.id.action_add) {
                    startActivity(new Intent(MainActivity.this, PostActivity.class));
                    return true;
                } else if (itemId == R.id.action_profile) {
                    startActivity(new Intent(MainActivity.this, ProfileActivity.class));
                    return true;
                }

                return false;
            }
        });
    }

    private void setupPosts() {
        List<Post> posts = new ArrayList<>();

        // Format URI untuk drawable: "android.resource://<package_name>/<res_id>"
        String packageName = getPackageName();

        posts.add(new Post("Adit", R.drawable.adit,
                "android.resource://" + packageName + "/" + R.drawable.adit,
                "Belajar di Universitas Hasanuddin!", 128, "1 JAM YANG LALU", null));

        posts.add(new Post("Dennis", R.drawable.dennis,
                "android.resource://" + packageName + "/" + R.drawable.dennis,
                "Halo dari Stanford University!", 321, "2 JAM YANG LALU", null));

        posts.add(new Post("Jarwo", R.drawable.jarwo,
                "android.resource://" + packageName + "/" + R.drawable.jarwo,
                "Kuliah di UGM mantap!", 256, "3 JAM YANG LALU", null));

        posts.add(new Post("Sopo", R.drawable.sopo,
                "android.resource://" + packageName + "/" + R.drawable.sopo,
                "UI emang keren!", 412, "4 JAM YANG LALU", null));

        posts.add(new Post("Adel", R.drawable.adel,
                "android.resource://" + packageName + "/" + R.drawable.adel,
                "Suasana kampus UB asri banget.", 298, "5 JAM YANG LALU", null));

        posts.add(new Post("Mita", R.drawable.mita,
                "android.resource://" + packageName + "/" + R.drawable.mita,
                "ITB penuh tantangan dan inspirasi!", 377, "6 JAM YANG LALU", null));

        posts.add(new Post("Devi", R.drawable.devi,
                "android.resource://" + packageName + "/" + R.drawable.devi,
                "Unair sangat ramah untuk mahasiswa!", 185, "7 JAM YANG LALU", null));

        posts.add(new Post("Pak Haji", R.drawable.hjudin,
                "android.resource://" + packageName + "/" + R.drawable.hjudin,
                "UNDIP penuh kenangan.", 423, "8 JAM YANG LALU", null));

        posts.add(new Post("Ucup", R.drawable.ucup,
                "android.resource://" + packageName + "/" + R.drawable.ucup,
                "UPN kampus perjuangan!", 390, "9 JAM YANG LALU", null));

        posts.add(new Post("Pak Anas", R.drawable.anas,
                "android.resource://" + packageName + "/" + R.drawable.anas,
                "UNM tempat berkarya.", 478, "10 JAM YANG LALU", null));

        PostAdapter adapter = new PostAdapter(this, posts);
        rvPosts.setLayoutManager(new LinearLayoutManager(this));
        rvPosts.setAdapter(adapter);
    }
}
