package com.example.instagramveiw.models;

import java.io.Serializable;

public class Post implements Serializable {

    private String username;
    private int userProfileImage; // Resource ID for user profile image
    private String postImageUri;  // URI to the post image
    private String caption;
    private int likes;
    private String timePosted;
    private String imagePath; // Optional: Local path to the image

    public Post(String username, int userProfileImage, String postImageUri,
                String caption, int likes, String timePosted, String imagePath) {
        this.username = username;
        this.userProfileImage = userProfileImage;
        this.postImageUri = postImageUri;
        this.caption = caption;
        this.likes = likes;
        this.timePosted = timePosted;
        this.imagePath = imagePath;
    }

    // Getter & Setter
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getUserProfileImage() {
        return userProfileImage;
    }

    public void setUserProfileImage(int userProfileImage) {
        this.userProfileImage = userProfileImage;
    }

    public String getPostImageUri() {
        return postImageUri;
    }

    public void setPostImageUri(String postImageUri) {
        this.postImageUri = postImageUri;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public String getTimePosted() {
        return timePosted;
    }

    public void setTimePosted(String timePosted) {
        this.timePosted = timePosted;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    // Menambahkan metode getPostImage() untuk memenuhi kebutuhan PostAdapter
    public String getPostImage() {
        return postImageUri;  // Kembalikan nilai postImageUri
    }
}
