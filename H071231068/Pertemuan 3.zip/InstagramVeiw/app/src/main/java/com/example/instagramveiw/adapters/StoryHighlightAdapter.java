package com.example.instagramveiw.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.instagramveiw.R;
import com.example.instagramveiw.activities.StoryDetailActivity;
import com.example.instagramveiw.models.StoryHighlight;

import java.util.List;

public class StoryHighlightAdapter extends RecyclerView.Adapter<StoryHighlightAdapter.HighlightViewHolder> {
    private Context context;
    private List<StoryHighlight> highlightList;

    public StoryHighlightAdapter(Context context, List<StoryHighlight> highlightList) {
        this.context = context;
        this.highlightList = highlightList;
    }

    @NonNull
    @Override
    public HighlightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_story_highlight, parent, false);
        return new HighlightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HighlightViewHolder holder, int position) {
        StoryHighlight highlight = highlightList.get(position);

        Glide.with(context).load(highlight.getCoverImage()).into(holder.imgCover);
        holder.tvTitle.setText(highlight.getTitle());


        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, StoryDetailActivity.class);
            intent.putExtra("title", highlight.getTitle());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return highlightList.size();
    }

    public static class HighlightViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCover;
        TextView tvTitle;


        public HighlightViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCover = itemView.findViewById(R.id.img_cover);
            tvTitle = itemView.findViewById(R.id.tv_title);

        }
    }
}
