package com.example.instagramveiw.models;



public class User {
    private String username;
    private String fullName;
    private String profileImage;

    public User(String username, String fullName, String profileImage) {
        this.username = username;
        this.fullName = fullName;
        this.profileImage = profileImage;
    }

    // Getters
    public String getUsername() { return username; }
    public String getFullName() { return fullName; }
    public String getProfileImage() { return profileImage; }
}