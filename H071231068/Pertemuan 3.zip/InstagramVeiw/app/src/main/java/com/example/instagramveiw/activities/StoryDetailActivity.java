package com.example.instagramveiw.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.instagramveiw.R;

public class StoryDetailActivity extends AppCompatActivity {
    private ImageView imgStory, imgClose;
    private TextView tvTitle, tvUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_detail);

        // Initialize views
        imgStory = findViewById(R.id.img_story);
        imgClose = findViewById(R.id.img_close);
        tvTitle = findViewById(R.id.tv_title);
        tvUsername = findViewById(R.id.tv_username);

        // Get story data from intent
        String title = getIntent().getStringExtra("title");
        String username = getIntent().getStringExtra("username");

        // Display story
        tvTitle.setText(title);
        tvUsername.setText(username);

        imgStory.setImageResource(R.drawable.ic_image_placeholder);


        imgClose.setOnClickListener(v -> finish());
    }
}