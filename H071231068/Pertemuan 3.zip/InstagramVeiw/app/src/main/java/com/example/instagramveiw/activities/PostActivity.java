package com.example.instagramveiw.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.instagramveiw.R;
import com.example.instagramveiw.models.Post;

import java.io.IOException;

public class PostActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView imgPost;
    private EditText etCaption;
    private Button btnShare;
    private Uri selectedImageUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        imgPost = findViewById(R.id.img_post);
        etCaption = findViewById(R.id.et_caption);
        btnShare = findViewById(R.id.btn_share);

        // Buka galeri saat gambar diklik
        imgPost.setOnClickListener(v -> openGallery());

        // Bagikan postingan
        btnShare.setOnClickListener(v -> {
            String caption = etCaption.getText().toString().trim();

            if (selectedImageUri == null) {
                Toast.makeText(this, "Silakan pilih gambar terlebih dahulu", Toast.LENGTH_SHORT).show();
                return;
            }

            if (caption.isEmpty()) {
                etCaption.setError("Caption tidak boleh kosong");
                return;
            }

            // Buat objek Post baru
            // Buat objek Post baru, kirimkan null untuk imagePath jika tidak ingin menggunakannya
            Post newPost = new Post(
                    "your_username",
                    R.drawable.ic_profile_placeholder,
                    selectedImageUri.toString(), // Kirim URI sebagai string
                    caption,
                    0,
                    "BARU SAJA",
                    "" // Gantikan dengan "" jika imagePath tidak digunakan, atau null
            );


            // Kirim kembali ke MainActivity
            Intent resultIntent = new Intent();
            resultIntent.putExtra("newPost", newPost);  // Pastikan Post implement Parcelable
            setResult(Activity.RESULT_OK, resultIntent);
            finish();
        });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                imgPost.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
