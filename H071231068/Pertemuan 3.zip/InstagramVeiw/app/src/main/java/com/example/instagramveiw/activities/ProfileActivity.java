package com.example.instagramveiw.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log; // Pastikan untuk mengimpor Log
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.instagramveiw.R;
import com.example.instagramveiw.adapters.ProfilePostAdapter;
import com.example.instagramveiw.adapters.StoryHighlightAdapter;
import com.example.instagramveiw.models.Post;
import com.example.instagramveiw.models.StoryHighlight;
import java.util.ArrayList;
import java.util.List;

public class ProfileActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_NEW_POST = 100;

    private ImageView imgProfile;
    private TextView tvUsername;
    private RecyclerView rvProfilePosts;
    private RecyclerView rvStoryHighlights;
    private Button btnNewPost;

    private List<Post> posts = new ArrayList<>();
    private ProfilePostAdapter postAdapter;

    private String username;
    private int profileImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Inisialisasi View
        imgProfile = findViewById(R.id.img_profile);
        tvUsername = findViewById(R.id.tv_username);
        rvProfilePosts = findViewById(R.id.rv_profile_posts);
        rvStoryHighlights = findViewById(R.id.rv_story_highlights);
        btnNewPost = findViewById(R.id.btn_new_post);



        // Ambil data dari Intent
        username = getIntent().getStringExtra("username");
        profileImage = getIntent().getIntExtra("profileImage", R.drawable.ic_profile_placeholder);

        // Validasi data user
        if (username == null || username.isEmpty()) {
            tvUsername.setText("Tidak ada data user.");
            return;
        }

        imgProfile.setImageResource(profileImage);
        tvUsername.setText(username);

        // Menampilkan log untuk memverifikasi data yang diterima
        Log.d("ProfileActivity", "Username: " + username);

        setupProfilePosts(username, profileImage);
        setupStoryHighlights();

        // Klik tombol Tambah Post
        btnNewPost.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, PostActivity.class);
            startActivityForResult(intent, REQUEST_CODE_NEW_POST);
        });
    }

    private void setupProfilePosts(String username, int profileImage) {
        String packageName = getPackageName();



        postAdapter = new ProfilePostAdapter(this, posts);
        rvProfilePosts.setLayoutManager(new GridLayoutManager(this, 3));
        rvProfilePosts.setAdapter(postAdapter);
    }

    private void setupStoryHighlights() {
        List<StoryHighlight> highlights = new ArrayList<>();
        highlights.add(new StoryHighlight(R.drawable.adit, "Pencapaian Adit"));
        highlights.add(new StoryHighlight(R.drawable.sopo, "Petualangan Sopo"));
        highlights.add(new StoryHighlight(R.drawable.hjudin, "Hidup Judin"));

        StoryHighlightAdapter adapter = new StoryHighlightAdapter(this, highlights);
        rvStoryHighlights.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvStoryHighlights.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_NEW_POST && resultCode == RESULT_OK && data != null) {
            Post newPost = (Post) data.getSerializableExtra("newPost");
            if (newPost != null) {
                posts.add(0, newPost);
                postAdapter.notifyItemInserted(0);
            }
        }
    }
}
