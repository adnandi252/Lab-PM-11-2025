package com.example.instagramveiw.models;

public class StoryHighlight {
    private int coverImage;
    private String title;

    public StoryHighlight(int coverImage, String title) {
        this.coverImage = coverImage;
        this.title = title;
    }

    public int getCoverImage() {
        return coverImage;
    }

    public void setCoverImage(int coverImage) {
        this.coverImage = coverImage;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
