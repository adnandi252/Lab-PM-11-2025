package com.example.instagramveiw.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.instagramveiw.R;
import com.example.instagramveiw.activities.ProfileActivity;
import com.example.instagramveiw.models.Post;
import com.bumptech.glide.Glide; // Import Glide

import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {
    private Context context;
    private List<Post> postList;

    public PostAdapter(Context context, List<Post> postList) {
        this.context = context;
        this.postList = postList;
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_post, parent, false);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        Post post = postList.get(position);

        // Load gambar profil
        holder.imgProfile.setImageResource(post.getUserProfileImage());
        holder.tvUsername.setText(post.getUsername());

        // Load gambar post pakai Glide
        Glide.with(context)
                .load(post.getPostImageUri())
                .into(holder.imgPost);

        // Set text caption dan waktu
        holder.tvCaption.setText(post.getUsername() + " " + post.getCaption());
        holder.tvTimePosted.setText(post.getTimePosted());

        // Set jumlah likes
        holder.tvLikes.setText(formatLikeCount(post.getLikes()) + " likes");

        // Click listener untuk buka profil
        View.OnClickListener profileClickListener = v -> {
            Intent intent = new Intent(context, ProfileActivity.class);
            intent.putExtra("username", post.getUsername());
            intent.putExtra("profileImage", post.getUserProfileImage()); // Tambahkan ini
            context.startActivity(intent);
        };

        holder.imgProfile.setOnClickListener(profileClickListener);
        holder.tvUsername.setOnClickListener(profileClickListener);

        // Like click
        holder.imgLike.setOnClickListener(v -> {
            Toast.makeText(context, "Liked " + post.getUsername(), Toast.LENGTH_SHORT).show();
        });
    }

    private String formatLikeCount(int likes) {
        if (likes >= 1000) {
            return String.format("%.1fK", likes / 1000.0);
        }
        return String.valueOf(likes);
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    public static class PostViewHolder extends RecyclerView.ViewHolder {
        ImageView imgProfile, imgPost, imgLike, imgComment, imgShare, imgSave;
        TextView tvUsername, tvLikes, tvCaption, tvTimePosted;

        public PostViewHolder(@NonNull View itemView) {
            super(itemView);
            imgProfile = itemView.findViewById(R.id.img_profile);
            imgPost = itemView.findViewById(R.id.img_post);
            imgLike = itemView.findViewById(R.id.img_like);
            imgComment = itemView.findViewById(R.id.img_comment);
            imgShare = itemView.findViewById(R.id.img_share);
            imgSave = itemView.findViewById(R.id.img_save);
            tvUsername = itemView.findViewById(R.id.tv_username);
            tvLikes = itemView.findViewById(R.id.tv_likes);
            tvCaption = itemView.findViewById(R.id.tv_caption);
            tvTimePosted = itemView.findViewById(R.id.tv_time_posted);
        }
    }
}
