package com.example.instagramveiw.activities;


import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.example.instagramveiw.R;
import com.example.instagramveiw.adapters.CommentAdapter;
import com.example.instagramveiw.models.Comment;
import com.example.instagramveiw.models.Post;
import java.util.ArrayList;
import java.util.List;

public class PostDetailActivity extends AppCompatActivity {
    private ImageView imgProfile, imgPost, imgLike, imgComment, imgShare, imgSave;
    private TextView tvUsername, tvLikes, tvCaption, tvTimePosted, tvPostComment;
    private EditText etComment;
    private RecyclerView rvComments;
    private boolean isLiked = false;
    private boolean isSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);

        // Initialize views
        initViews();

        // Get post data from intent
        Post post = (Post) getIntent().getSerializableExtra("post");
        if (post != null) {
            displayPostDetails(post);
        }

        // Setup comments
        setupComments();

        // Set click listeners
        setClickListeners();
    }

    private void initViews() {
        imgProfile = findViewById(R.id.img_profile);
        imgPost = findViewById(R.id.img_post);
        imgLike = findViewById(R.id.img_like);
        imgComment = findViewById(R.id.img_comment);
        imgShare = findViewById(R.id.img_share);
        imgSave = findViewById(R.id.img_save);
        tvUsername = findViewById(R.id.tv_username);
        tvLikes = findViewById(R.id.tv_likes);
        tvCaption = findViewById(R.id.tv_caption);
        tvTimePosted = findViewById(R.id.tv_time_posted);
        tvPostComment = findViewById(R.id.tv_post_comment);
        etComment = findViewById(R.id.et_comment);
        rvComments = findViewById(R.id.rv_comments);

        // Setup toolbar
        findViewById(R.id.toolbar).setOnClickListener(v -> finish());
    }

    // In PostDetailActivity.java, modify the displayPostDetails method:
    private void displayPostDetails(Post post) {
        imgProfile.setImageResource(post.getUserProfileImage());
        Glide.with(this)
                .load(post.getPostImageUri())  // Gunakan Glide untuk memuat gambar dari URI
                .into(imgPost);

        tvUsername.setText(post.getUsername());
        tvLikes.setText(formatLikeCount(post.getLikes()) + " suka");
        tvCaption.setText(post.getCaption());
        tvTimePosted.setText(post.getTimePosted());
    }

    private String formatLikeCount(int likes) {
        if (likes >= 1000) {
            return String.format("%.1fK", likes / 1000.0);
        }
        return String.valueOf(likes);
    }

    private void setupComments() {
        // Dummy comments data
        List<Comment> comments = new ArrayList<>();
        comments.add(new Comment("user1", "https://example.com/profile1.jpg", "Nice post!", "10m ago"));
        comments.add(new Comment("user2", "https://example.com/profile2.jpg", "Awesome!", "15m ago"));
        // Add more comments...

        CommentAdapter adapter = new CommentAdapter(this, comments);
        rvComments.setLayoutManager(new LinearLayoutManager(this));
        rvComments.setAdapter(adapter);
    }

    private void setClickListeners() {
        // Like button
        imgLike.setOnClickListener(v -> {
            isLiked = !isLiked;
            imgLike.setImageResource(isLiked ? R.drawable.ic_like_filled : R.drawable.ic_like_outline);
            if (isLiked) {
                imgLike.setColorFilter(getResources().getColor(R.color.red));
            } else {
                imgLike.setColorFilter(getResources().getColor(R.color.black));
            }
        });

        // Save button
        imgSave.setOnClickListener(v -> {
            isSaved = !isSaved;
            imgSave.setImageResource(isSaved ? R.drawable.ic_save_filled : R.drawable.ic_save);
        });

        // Post comment
        tvPostComment.setOnClickListener(v -> {
            String commentText = etComment.getText().toString().trim();
            if (!commentText.isEmpty()) {
                // Add new comment to list
                addNewComment(commentText);
                etComment.setText("");
            }
        });

        // Profile click
        imgProfile.setOnClickListener(v -> {
            // Navigate to profile
        });

        // Username click
        tvUsername.setOnClickListener(v -> {
            // Navigate to profile
        });
    }

    private void addNewComment(String commentText) {
        // In a real app, you would add this to your database
        // Here we just add it to the RecyclerView for demo purposes
        Comment newComment = new Comment(
                "current_user",
                "https://example.com/current_profile.jpg",
                commentText,
                "Just now"
        );

        CommentAdapter adapter = (CommentAdapter) rvComments.getAdapter();
        if (adapter != null) {
            adapter.addComment(newComment);
            rvComments.smoothScrollToPosition(adapter.getItemCount() - 1);
        }
    }
}