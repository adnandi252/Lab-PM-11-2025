package com.example.instagramveiw.models;

public class Comment {
    private String username;
    private String profileImage;
    private String text;
    private String time;

    public Comment(String username, String profileImage, String text, String time) {
        this.username = username;
        this.profileImage = profileImage;
        this.text = text;
        this.time = time;
    }

    // Getters
    public String getUsername() { return username; }
    public String getProfileImage() { return profileImage; }
    public String getText() { return text; }
    public String getTime() { return time; }
}