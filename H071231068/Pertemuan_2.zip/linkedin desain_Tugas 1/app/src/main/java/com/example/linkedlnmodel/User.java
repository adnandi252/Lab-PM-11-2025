package com.example.linkedlnmodel;

import android.net.Uri;
import  android.os.Parcel;
import android.os.Parcelable;

public class User  implements Parcelable{

    private  String name, Univ, About,HighlightDetail, Alamat, Profesi ;
    private  Uri imageUri;


    public User(String name, String univ, String about, String highlightDetail, String alamat, String profesi, Uri imageUri) {
        this.name = name;
        Univ = univ;
        About = about;
        HighlightDetail = highlightDetail;
        Alamat = alamat;
        Profesi = profesi;
        this.imageUri = imageUri;
    }

    protected User(Parcel in) {
        name = in.readString();
        imageUri = in.readParcelable(Uri.class.getClassLoader());
        About = in.readString();
        Univ = in.readString();
        Alamat = in.readString();
        Profesi = in.readString();
        HighlightDetail = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeParcelable(imageUri, flags);
        dest.writeString(About);
        dest.writeString(Univ);
        dest.writeString(Alamat);
        dest.writeString(Profesi);
        dest.writeString(HighlightDetail);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getName() {
        return name;
    }

    public  String getUniv() {
        return Univ;
    }

    public String getAlamat() {
        return Alamat;
    }


    public String getProfesi() {
        return Profesi;
    }
    public Uri getProfileImage() {
        return imageUri;
    }

    public String getAbout() {
        return About;
    }

    public String getHighlightDetail() {
        return HighlightDetail;
    }





}
