package com.example.linkedlnmodel;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;

public class EditProfileActivity extends AppCompatActivity {
    private static final int PICK_IMAGE = 1;
    private static final int CAPTURE_IMAGE = 2;

    private EditText editTextName,editTextAbout, editTextHighlightDetail,editTextUniv, editTextAlamat, editTextProfesi  ;


    private ImageView imageViewProfile;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        editTextName = findViewById(R.id.editTextName);
        editTextUniv = findViewById(R.id.editTextUniv);
        editTextAbout = findViewById(R.id.editTextAbout);
        editTextAlamat = findViewById(R.id.editTextAlamat);
        editTextProfesi = findViewById(R.id.editTextProfesi);
        editTextHighlightDetail = findViewById(R.id.editTextHighlightDetail);
        imageViewProfile = findViewById(R.id.imageViewProfile);
        Button buttonSave = findViewById(R.id.buttonSave);

        // Ambil data dari MainActivity
        Intent intent = getIntent();
        User user = intent.getParcelableExtra("user");

        if (user.getName() != null) editTextName.setText(user.getName());
        if (user.getUniv() != null) editTextUniv.setText(user.getUniv());
        if (user.getAlamat() != null) editTextAlamat.setText(user.getAlamat());
        if (user.getProfesi() != null) editTextProfesi.setText(user.getProfesi());
        if (user.getAbout() != null) editTextAbout.setText(user.getAbout());
        if (user.getHighlightDetail() != null) editTextHighlightDetail.setText(user.getHighlightDetail());
        if (user.getProfileImage() != null) {
            imageUri = user.getProfileImage();
            imageViewProfile.setImageURI(imageUri);
        }

        imageViewProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImageSource();
            }
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                String about = editTextAbout.getText().toString();
                String univ = editTextUniv.getText().toString();
                String alamat = editTextAlamat.getText().toString();
                String profesi = editTextProfesi.getText().toString();
                String highlightDetail = editTextHighlightDetail.getText().toString();
                boolean isValid = true;

                if (name.isEmpty()) {
                    editTextName.setError("Nama tidak boleh kosong");
                    isValid = false;
                }

                if (univ.isEmpty()) {
                    editTextUniv.setError("Universitas tidak boleh kosong");
                    isValid = false;
                }

                if (alamat.isEmpty()) {
                    editTextAlamat.setError("Alamat tidak boleh kosong");
                    isValid = false;
                }

                if (profesi.isEmpty()) {
                    editTextProfesi.setError("Profesi tidak boleh kosong");
                    isValid = false;
                }

                if (isValid) {
                    User user = new User(name,  univ, about , highlightDetail, alamat ,profesi , imageUri);
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("user", user);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                } else {
                    Toast.makeText(EditProfileActivity.this, "Mohon lengkapi data yang wajib diisi", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void chooseImageSource() {
        String[] options = {"Camera", "Gallery"};
        new AlertDialog.Builder(this)
                .setTitle("Choose Image Source")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        openCamera();
                    } else {
                        openGallery();
                    }
                })
                .show();
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            if (photoFile != null) {
                imageUri = FileProvider.getUriForFile(this,
                        "com.example.yourapp.fileprovider", // pastikan ini sesuai dengan `provider` di AndroidManifest.xml
                        photoFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, CAPTURE_IMAGE);
            }
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == PICK_IMAGE && data != null) {
                imageUri = data.getData();
                imageViewProfile.setImageURI(imageUri);
            } else if (requestCode == CAPTURE_IMAGE) {
                imageViewProfile.setImageURI(imageUri);
            }
        }
    }

    private File createImageFile() throws IOException {
        String imageFileName = "JPEG_" + System.currentTimeMillis() + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }
}
