package com.example.linkedlnmodel;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final int EDIT_PROFILE_REQUEST = 1;

    private TextView textNama, textAbout, textUniv, textHighlightDetail, textAlamat, textProfeso;
    private ImageView imageViewProfile;

    private Uri currentImageUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi komponen UI
        textNama = findViewById(R.id.textNama);
        imageViewProfile = findViewById(R.id.gambar2);
        textAbout = findViewById(R.id.isiAbout);
        textUniv = findViewById(R.id.univ);
        textAlamat = findViewById(R.id.alamat);
        textProfeso = findViewById(R.id.profesi);
        textHighlightDetail = findViewById(R.id.textHighlightDetail);

        ImageView buttonEditProfile = findViewById(R.id.buttonEditProfile);
        buttonEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Buat objek User dari data saat ini
                User user = new User(
                        textNama.getText().toString(),
                        textUniv.getText().toString(),
                        textAbout.getText().toString(),
                        textHighlightDetail.getText().toString(),
                        textAlamat.getText().toString(),
                        textProfeso.getText().toString(),
                        currentImageUri
                );

                Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
                intent.putExtra("user", user);
                startActivityForResult(intent, EDIT_PROFILE_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDIT_PROFILE_REQUEST && resultCode == RESULT_OK && data != null) {
            User user = data.getParcelableExtra("user");
            if (user != null) {
                textNama.setText(user.getName());
                textAbout.setText(user.getAbout());
                textUniv.setText(user.getUniv());
                textAlamat.setText(user.getAlamat());
                textProfeso.setText(user.getProfesi());
                textHighlightDetail.setText(user.getHighlightDetail());
                if (user.getProfileImage() != null) {
                    currentImageUri = user.getProfileImage();
                    imageViewProfile.setImageURI(currentImageUri);
                }
            }
        }
    }
}
