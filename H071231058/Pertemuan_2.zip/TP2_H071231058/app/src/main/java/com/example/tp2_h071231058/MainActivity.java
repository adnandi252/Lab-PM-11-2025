package com.example.tp2_h071231058;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    private CardView imgProfile;
    private ImageView profileImage, ivProfile;
    private TextView tvName, tvUsername, tvPronouns, tvBio;
    private String imageUriString = "";
    private TextView tvThreads;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        imgProfile = findViewById(R.id.imgProfile);
        profileImage = imgProfile.findViewById(R.id.profileImage);
        ivProfile = findViewById(R.id.ivProfile);
        tvName = findViewById(R.id.tvName);
        tvUsername = findViewById(R.id.tvUsername);
        tvPronouns = findViewById(R.id.tvPronouns);
        tvBio = findViewById(R.id.tvBio);
        tvThreads = findViewById(R.id.tvThreads);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("USER_DATA")) {
            User user = intent.getParcelableExtra("USER_DATA");

            if (user != null) {
                tvName.setText(user.getName());
                tvUsername.setText(user.getUsername());
                tvPronouns.setText(user.getPronouns());
                tvBio.setText(user.getBio());

                imageUriString = user.getImageUri();
                if (imageUriString != null && !imageUriString.isEmpty()) {
                    Uri imageUri = Uri.parse(imageUriString);
                    profileImage.setImageURI(imageUri);
                    ivProfile.setImageURI(imageUri);
                }

                boolean showThreads = intent.getBooleanExtra("SHOW_THREADS", false);
                if (showThreads) {
                    tvThreads.setText("@" + user.getUsername());
                    tvThreads.setVisibility(View.VISIBLE);
                } else {
                    tvThreads.setVisibility(View.GONE);
                }
            }
        }


        Button editProfile = findViewById(R.id.btnEditProfile);
        editProfile.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);

                User user = new User(
                        tvName.getText().toString(),
                        tvUsername.getText().toString(),
                        tvPronouns.getText().toString(),
                        tvBio.getText().toString(),
                        imageUriString
                );

                intent.putExtra("USER_DATA", user);

                startActivity(intent);
            }
        });


    }
}
