package com.example.tp2_h071231058;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class EditProfileActivity extends AppCompatActivity {

    private ImageView imgProfile, ivCheck;
    private EditText etName, etUsername, etPronouns, etBio;
    private Uri imageUri;
    private SwitchMaterial switchThreads;
    private boolean showThreads = false;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_profile);

        imgProfile = findViewById(R.id.imgProfile);
        etName = findViewById(R.id.etName);
        etUsername = findViewById(R.id.etUsername);
        etPronouns = findViewById(R.id.etPronouns);
        etBio = findViewById(R.id.etBio);
        ivCheck = findViewById(R.id.ivCheck);
        switchThreads = findViewById(R.id.smThreads);

        imgProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bukagaleri = new Intent(Intent.ACTION_GET_CONTENT);
                bukagaleri.setType("image/*");
                openGallery.launch(Intent.createChooser(bukagaleri, "Choose a picture"));
            }
        });


        ivCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = "";
                String username = "";
                String pronouns = "";
                String bio = "";

                if (etName.getText() != null) {
                    name = etName.getText().toString();
                }

                if (etUsername.getText() != null) {
                    username = etUsername.getText().toString();
                }

                if (etPronouns.getText() != null) {
                    pronouns = etPronouns.getText().toString();
                }

                if (etBio.getText() != null) {
                    bio = etBio.getText().toString();
                }

                String imageUriString = "";
                if (imageUri != null) {
                    imageUriString = imageUri.toString();
                }

                if (username.isEmpty()) {
                    etUsername.setError("Username cannot be empty");
                    return;
                }

                User user = new User(name, username, pronouns, bio, imageUriString);

                Intent intent = new Intent(EditProfileActivity.this, MainActivity.class);

                intent.putExtra("USER_DATA", user);

                showThreads = switchThreads.isChecked();
                intent.putExtra("SHOW_THREADS", showThreads);


                startActivity(intent);
                finish();
            }
        });

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("USER_DATA")) {
            User user = intent.getParcelableExtra("USER_DATA");

            if (user != null) {
                etName.setText(user.getName());
                etUsername.setText(user.getUsername());
                etPronouns.setText(user.getPronouns());
                etBio.setText(user.getBio());

                if (user.getImageUri() != null && !user.getImageUri().isEmpty()) {
                    imageUri = Uri.parse(user.getImageUri());
                    imgProfile.setImageURI(imageUri);
                }
            }
        }

        ImageView ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditProfileActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    ActivityResultLauncher<Intent> openGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            imageUri = data.getData();
                            imgProfile.setImageURI(imageUri);
                        }
                    }
                }
            }
    );
}
