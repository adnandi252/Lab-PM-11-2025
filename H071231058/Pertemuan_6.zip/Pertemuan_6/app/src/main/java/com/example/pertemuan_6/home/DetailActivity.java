package com.example.pertemuan_6.home;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.example.pertemuan_6.R;
import com.example.pertemuan_6.data.network.ApiConfig;
import com.example.pertemuan_6.data.response.ResultsItem;
import com.example.pertemuan_6.databinding.ActivityDetailBinding;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailActivity extends AppCompatActivity {

    private ActivityDetailBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.detail), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int userId = getIntent().getIntExtra("id", -1);
//        if (userId != -1) {
//            fetchUserDetail(userId);
//        } else {
//            showErrorUI("ID tidak ditemukan");
//            finish();
//        }

        if (!isInternetAvailable()) {
            showErrorUI("ID tidak ditemukan");
        } else if (userId != -1) {
            fetchUserDetail(userId);
        }

    }

    private void fetchUserDetail(int id) {
        ApiConfig.getApiService().getUserDetail(id).enqueue(new Callback<ResultsItem>() {
            @Override
            public void onResponse(Call<ResultsItem> call, Response<ResultsItem> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ResultsItem user = response.body();
                    binding.tvDetailName.setText(user.getName());
                    binding.tvDetailStatusSpecies.setText(user.getStatus() + " - " + user.getSpecies());
                    binding.tvDetailGender.setText("Gender: " + user.getGender());
                    binding.tvDetailOrigin.setText("Origin: " + user.getOrigin().getName());
                    binding.tvDetailLocation.setText("Location: " + user.getLocation().getName());
                    Glide.with(DetailActivity.this)
                            .load(user.getImage())
                            .into(binding.ivDetailImage);
                } else {
                    showErrorUI("Periksa koneksi internet Anda");
                }
            }

            @Override
            public void onFailure(Call<ResultsItem> call, Throwable t) {
                showErrorUI("Periksa koneksi internet Anda");
            }
        });
    }

    private boolean isInternetAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnected();
    }

    public void showErrorUI(String message) {
        binding.tvDetailName.setText("Data tidak tersedia");
        binding.tvDetailStatusSpecies.setText("");
        binding.tvDetailGender.setText("");
        binding.tvDetailOrigin.setText("");
        binding.tvDetailLocation.setText("");
        binding.ivDetailImage.setImageDrawable(null); // hapus gambar sebelumnya

        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

}