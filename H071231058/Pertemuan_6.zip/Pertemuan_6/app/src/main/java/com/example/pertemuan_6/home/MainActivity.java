package com.example.pertemuan_6.home;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.pertemuan_6.R;
import com.example.pertemuan_6.data.network.ApiConfig;
import com.example.pertemuan_6.data.response.ResultsItem;
import com.example.pertemuan_6.data.response.UserResponse;
import com.example.pertemuan_6.databinding.ActivityMainBinding;
import com.example.pertemuan_6.ui.UserAdapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private UserAdapter adapter;
    private List<ResultsItem> userList = new ArrayList<>();
    private int currentPage = 1;
    private boolean isLoading = false;
    private boolean isLastPage = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        adapter = new UserAdapter(userList, this);
        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        binding.rvUser.setLayoutManager(layoutManager);
        binding.rvUser.setAdapter(adapter);

        binding.btnLoadMore.setVisibility(View.GONE);
        binding.loadMoreProgress.setVisibility(View.GONE);

        fetchData(currentPage);

        binding.btnLoadMore.setOnClickListener(v -> {
            if (!isLoading && !isLastPage) {
                binding.btnLoadMore.setVisibility(View.GONE);
                binding.loadMoreProgress.setVisibility(View.VISIBLE);

                int nextPage = currentPage + 1;
                fetchData(nextPage);
            }
        });
    }

    private void fetchData(int page) {
        isLoading = true;

        if (currentPage == 1) {
            binding.progressBar.setVisibility(View.VISIBLE);
        }

        Call<UserResponse> call = ApiConfig.getApiService().getListUsers(page);
        call.enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                isLoading = false;
                binding.progressBar.setVisibility(View.GONE);
                binding.loadMoreProgress.setVisibility(View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    List<ResultsItem> newUsers = response.body().getResults();
                    if (newUsers.isEmpty()) {
                        isLastPage = true;
                        binding.btnLoadMore.setVisibility(View.GONE);
                        Toast.makeText(MainActivity.this, "Tidak dapat terhubung", Toast.LENGTH_SHORT).show();
                    } else {
                        userList.addAll(newUsers);
                        adapter.notifyDataSetChanged();
                        currentPage = page;

                        if (!isLastPage) {
                            binding.btnLoadMore.setVisibility(View.VISIBLE);
                        }
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Gagal load data!", Toast.LENGTH_SHORT).show();
                }

                binding.btnLoadMore.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                isLoading = false;
                binding.progressBar.setVisibility(View.GONE);
                binding.loadMoreProgress.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "Tidak dapat terhubung ke server. Periksa koneksi internet Anda.", Toast.LENGTH_LONG).show();

                binding.btnLoadMore.setVisibility(View.VISIBLE);
            }
        });
    }

    public boolean isInternetAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnected();
    }

}
