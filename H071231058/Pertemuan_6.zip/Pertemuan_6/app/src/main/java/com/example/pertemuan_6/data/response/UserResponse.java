package com.example.pertemuan_6.data.response;

import java.util.List;

public class UserResponse{
	private List<ResultsItem> results;
	private Info info;

	public List<ResultsItem> getResults(){
		return results;
	}

	public Info getInfo(){
		return info;
	}
}