package com.example.pertemuan_6.data.response;

public class Origin{
	private String name;
	private String url;

	public String getName(){
		return name;
	}

	public String getUrl(){
		return url;
	}
}
