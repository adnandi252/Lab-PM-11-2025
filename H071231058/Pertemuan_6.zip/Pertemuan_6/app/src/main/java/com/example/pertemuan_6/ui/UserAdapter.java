package com.example.pertemuan_6.ui;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.pertemuan_6.data.response.ResultsItem;
import com.example.pertemuan_6.databinding.ItemUserBinding;
import com.example.pertemuan_6.home.DetailActivity;
import com.example.pertemuan_6.home.MainActivity;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private final List<ResultsItem> userList;
    private final Context context;

    public UserAdapter(List<ResultsItem> userList, Context context) {
        this.userList = userList;
        this.context = context;
    }

    @NonNull
    @Override
    public UserAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ItemUserBinding binding = ItemUserBinding.inflate(inflater, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapter.ViewHolder holder, int position) {
        ResultsItem user = userList.get(position);
        Glide.with(holder.itemView.getContext())
                .load(user.getImage())
                .into(holder.binding.ivImage);

        holder.binding.tvName.setText(user.getName());
        holder.binding.tvSpecies.setText(user.getSpecies());

        // Klik item untuk pindah ke DetailActivity
        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("id", user.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemUserBinding binding;

        public ViewHolder(ItemUserBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
