package com.example.pertemuan_6.data.response;

public class Info{
	private String next;
	private int pages;
	private Object prev;
	private int count;

	public String getNext(){
		return next;
	}

	public int getPages(){
		return pages;
	}

	public Object getPrev(){
		return prev;
	}

	public int getCount(){
		return count;
	}
}
