package com.example.pertemuan_7;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pertemuan_7.database.DatabaseContract;
import com.example.pertemuan_7.database.NotesHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_UPDATE = 200;
    private final int REQUEST_ADD = 100;

    private TextView noData;
    private NotesAdapter notesAdapter;
    private NotesHelper notesHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Notes List");
        }

        EditText etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchNotes(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        RecyclerView rvNotes = findViewById(R.id.rvNotes);
        FloatingActionButton fabAdd = findViewById(R.id.fab_add);
        noData = findViewById(R.id.noData);

        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        rvNotes.setLayoutManager(layoutManager);

        notesAdapter = new NotesAdapter(this);
        rvNotes.setAdapter(notesAdapter);

        notesHelper = NotesHelper.getInstance(getApplicationContext());

        fabAdd.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            startActivityForResult(intent, REQUEST_ADD);
        });

        loadNotes();
    }

    private void loadNotes() {
        new LoadNotesAsync(this, notes -> {
            if (!notes.isEmpty()) {
                notesAdapter.setNotes(notes);
                noData.setVisibility(View.GONE);
            } else {
                notesAdapter.setNotes(new ArrayList<>());
                noData.setVisibility(View.VISIBLE);
            }
        }).execute();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ADD) {
            if (resultCode == DetailActivity.RESULT_ADD) {
                showToast("Notes added successfully");
                loadNotes();
            }
        } else if (requestCode == REQUEST_UPDATE) {
            if (resultCode == DetailActivity.RESULT_UPDATE) {
                showToast("Notes updated successfully");
                loadNotes();
            } else if (resultCode == DetailActivity.RESULT_DELETE) {
                showToast("Notes deleted successfully");
                loadNotes();
            }
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (notesHelper != null) {
            notesHelper.close();
        }
    }

    private static class LoadNotesAsync {
        private final WeakReference<Context> weakContext;
        private final WeakReference<LoadNotesCallback> weakCallback;

        private LoadNotesAsync(Context context, LoadNotesCallback callback) {
            weakContext = new WeakReference<>(context);
            weakCallback = new WeakReference<>(callback);
        }

        void execute() {
            ExecutorService executor = Executors.newSingleThreadExecutor();
            Handler handler = new Handler(Looper.getMainLooper());

            executor.execute(() -> {
                Context context = weakContext.get();
                if (context != null) {
                    NotesHelper notesHelper = NotesHelper.getInstance(context);
                    notesHelper.open();

                    Cursor cursor = notesHelper.queryAll();
                    ArrayList<Note> notes = MappingHelper.mapCursorToArrayList(cursor);
                    cursor.close();

                    handler.post(() -> {
                        LoadNotesCallback callback = weakCallback.get();
                        if (callback != null) {
                            callback.postExecute(notes);
                        }
                    });
                }
            });
        }
    }

    interface LoadNotesCallback {
        void postExecute(ArrayList<Note> notes);
    }

    private void searchNotes(String query) {
        notesHelper.open();
        Cursor cursor = notesHelper.searchByTitle(query);

        ArrayList<Note> notesList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                Note note = new Note();
                note.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn._ID)));
                note.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn.TITLE)));
                note.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn.DESCRIPTION)));
                note.setCreated_at(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn.CREATED_AT)));
                note.setUpdated_at(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn.UPDATED_AT)));
                notesList.add(note);
            } while (cursor.moveToNext());
        }

        cursor.close();
        notesHelper.close();

        notesAdapter.setNotes(notesList);
    }
}
