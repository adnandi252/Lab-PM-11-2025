package com.example.pertemuan_7;

import android.database.Cursor;

import com.example.pertemuan_7.database.DatabaseContract;

import java.util.ArrayList;

public class MappingHelper {
    public static ArrayList<Note> mapCursorToArrayList(Cursor cursor) {
        ArrayList<Note> students = new ArrayList<>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn._ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn.TITLE));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn.DESCRIPTION));
            String created_at = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn.CREATED_AT));
            String updated_at = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.NotesColumn.UPDATED_AT));
            students.add(new Note(id, title, description, created_at, updated_at));
        }
        return students;
    }
}