package com.example.pertemuan_7.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class NotesHelper {
    public static String TABLE_NAME = DatabaseContract.TABLE_NAME;
    private final DatabaseHelper databaseHelper;
    private SQLiteDatabase sqLiteDatabase;

    public static volatile NotesHelper INSTANCE;

    public static NotesHelper getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (NotesHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new NotesHelper(context);
                }
            }
        }
        return INSTANCE;
    }

    public NotesHelper(Context context) {
        databaseHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        sqLiteDatabase = databaseHelper.getWritableDatabase();
    }

    public void close() {
        databaseHelper.close();
        if (sqLiteDatabase != null && sqLiteDatabase.isOpen()) {
            sqLiteDatabase.close();
        }
    }

    public Cursor queryAll() {
        return sqLiteDatabase.query(
                TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                DatabaseContract.NotesColumn._ID + " DESC"
        );
    }


    public long insert(ContentValues values) {
        return sqLiteDatabase.insert(TABLE_NAME, null, values);
    }

    public int update(String id, ContentValues values) {
        return sqLiteDatabase.update(
                TABLE_NAME,
                values,
                DatabaseContract.NotesColumn._ID + " = ?",
                new String[]{id}
        );
    }

    public int deleteById(String id) {
        return sqLiteDatabase.delete(
                TABLE_NAME,
                DatabaseContract.NotesColumn._ID + " = ?",
                new String[]{id}
        );
    }

    public Cursor searchByTitle(String query) {
        return sqLiteDatabase.query(
                TABLE_NAME,
                null,
                DatabaseContract.NotesColumn.TITLE + " LIKE ?",
                new String[]{"%" + query + "%"},
                null,
                null,
                DatabaseContract.NotesColumn.UPDATED_AT + " DESC"
        );
    }
}
