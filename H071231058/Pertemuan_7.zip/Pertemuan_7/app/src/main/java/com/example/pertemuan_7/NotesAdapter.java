package com.example.pertemuan_7;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.NotesViewHolder> {

    private final ArrayList<Note> notes = new ArrayList<>();
    private final Activity activity;

    public NotesAdapter(Activity activity) {
        this.activity = activity;
    }

    public void setNotes(ArrayList<Note> notes) {
        this.notes.clear();
        if (notes.size() > 0) {
            this.notes.addAll(notes);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NotesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_note, parent, false);
        return new NotesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotesViewHolder holder, int position) {
        holder.bind(notes.get(position));
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    class NotesViewHolder extends RecyclerView.ViewHolder {
        final TextView tvTitle, tvDescription, tvDate;
        final CardView cardView;

        NotesViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvDate = itemView.findViewById(R.id.tvDate);
            cardView = itemView.findViewById(R.id.card_view);
        }

        void bind(Note notes) {
            tvTitle.setText(notes.getTitle());
            tvDescription.setText(notes.getDescription());

            String dateLabel;
            if (notes.getUpdated_at() != null
                    && !notes.getUpdated_at().isEmpty()
                    && !notes.getUpdated_at().equals(notes.getCreated_at())) {
                dateLabel = "Updated at " + notes.getUpdated_at();
            } else {
                dateLabel = "Created at " + notes.getCreated_at();
            }

            tvDate.setText(dateLabel);

            cardView.setOnClickListener(v -> {
                Intent intent = new Intent(activity, DetailActivity.class);
                intent.putExtra(DetailActivity.EXTRA_NOTES, notes);
                activity.startActivityForResult(intent, DetailActivity.REQUEST_UPDATE);
            });
        }
    }
}
