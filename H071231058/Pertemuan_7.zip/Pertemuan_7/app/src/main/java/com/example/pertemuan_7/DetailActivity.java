package com.example.pertemuan_7;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pertemuan_7.database.DatabaseContract;
import com.example.pertemuan_7.database.NotesHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_NOTES = "extra_notes";
    public static final int RESULT_ADD = 101;
    public static final int RESULT_UPDATE = 201;
    public static final int RESULT_DELETE = 301;
    public static final int REQUEST_UPDATE = 200;

    private NotesHelper notesHelper;
    private Note notes;
    private EditText etTitle, etDescription;
    private ImageButton ibBack, ibSave, ibDelete;
    private boolean isEdit = false;
    private boolean isSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etTitle = findViewById(R.id.etTitle);
        etDescription = findViewById(R.id.etDescription);
        ibBack = findViewById(R.id.ibBack);
        ibSave = findViewById(R.id.ibSave);
        ibDelete = findViewById(R.id.ibDelete);

        notesHelper = NotesHelper.getInstance(this);
        notesHelper.open();

        notes = getIntent().getParcelableExtra(EXTRA_NOTES);
        if (notes != null) {
            isEdit = true;
        } else {
            notes = new Note();
        }

        String actionBarTitle;

        if (isEdit) {
            actionBarTitle = "Edit Notes";

            if (notes != null) {
                etTitle.setText(notes.getTitle());
                etDescription.setText(notes.getDescription());
            }
            ibDelete.setVisibility(View.VISIBLE);

        } else {
            actionBarTitle = "Add Notes";
        }

        ibSave.setVisibility(View.VISIBLE);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(actionBarTitle);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        ibSave.setOnClickListener(v -> {
            saveNotes();
            isSaved = true;
            finish();
        });

        ibDelete.setOnClickListener(view -> deleteNotes());

        ibBack.setOnClickListener(v -> {
            if (isSaved) {
                finish();
            } else {
                String title = etTitle.getText().toString().trim();
                String desc = etDescription.getText().toString().trim();

                if (!title.isEmpty() || !desc.isEmpty()) {
                    showUnsavedDialog();
                } else {
                    finish();
                }
            }
        });

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String title = etTitle.getText().toString().trim();
                String desc = etDescription.getText().toString().trim();
                ibSave.setVisibility((title.isEmpty() && desc.isEmpty()) ? View.GONE : View.VISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        etTitle.addTextChangedListener(textWatcher);
        etDescription.addTextChangedListener(textWatcher);
    }

    private void showUnsavedDialog() {
        new AlertDialog.Builder(this)
                .setMessage("Save your changes?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    saveNotes();
                    isSaved = true;
                    finish();
                })
                .setNegativeButton("No", (dialog, which) -> finish())
                .setCancelable(true)
                .show();
    }

    private void saveNotes() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String currentTime = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault()).format(new Date());

        if (title.isEmpty() && description.isEmpty()) {
            ibSave.setVisibility(View.GONE);
            Toast.makeText(this, "Note is empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (title.isEmpty() && !description.isEmpty()) {
            title = "Untitled";
        }

        notes.setTitle(title);
        notes.setDescription(description);

        Intent intent = new Intent();
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.NotesColumn.TITLE, title);
        values.put(DatabaseContract.NotesColumn.DESCRIPTION, description);
        values.put(DatabaseContract.NotesColumn.UPDATED_AT, currentTime);

        if (isEdit) {
            notes.setUpdated_at(currentTime);
            long result = notesHelper.update(String.valueOf(notes.getId()), values);
            Log.d("DetailActivity", "ID to update/delete: " + notes.getId());

            if (result > 0) {
                setResult(RESULT_UPDATE, intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to update data", Toast.LENGTH_SHORT).show();
            }

        } else {
            notes.setCreated_at(currentTime);
            values.put(DatabaseContract.NotesColumn.CREATED_AT, currentTime);
            notes.setUpdated_at(null);

            long result = notesHelper.insert(values);
            if (result > 0) {
                notes.setId((int) result);
                intent.putExtra(EXTRA_NOTES, notes);
                setResult(RESULT_ADD, intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to add data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void deleteNotes() {
        if (notes != null && notes.getId() > 0) {
            long result = notesHelper.deleteById(String.valueOf(notes.getId()));

            if (result > 0) {
                setResult(RESULT_DELETE);
                finish();
            } else {
                Toast.makeText(this, "Failed to delete data", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Failed to delete data", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (notesHelper != null) {
            notesHelper.close();
        }
    }
}
